create table ACTIONS
(
    ID int NOT NULL,
    ACTNAME varchar(100) NOT NULL,
    PLACE varchar(200),
    DESCRIPTION varchar (1000),
    STARTDATE date,
    ENDDATE date,
    PRIMARY KEY (ID)
);

create table USERS
(
    LOGIN varchar (100) NOT NULL,
    PASSWORD varchar (100) NOT NULL,
    ISADMIN integer NOT NULL,
    ISSUPERADMIN integer NOT NULL,
    ACTIONID int NOT NULL,
    PRIMARY KEY (LOGIN),
    FOREIGN KEY (ACTIONID) REFERENCES ACTIONS (ID)
);
insert into ACTIONS values (0, 'sjezd', 'dolany', 'sjedeme se v dolanech', '31.10.2011', '5.11.2011');
insert into USERS values ('Lahvi', 'lahvi', 1, 1, 0);

create table PARTICIPANTS
(
    LOGIN varchar(100) NOT NULL,
    PASSWORD varchar(100) NOT NULL,
    IDCARTNUM int NOT NULL,
    ADDRESS varchar(200),
    ACTIONID int NOT NULL,
    PRIMARY KEY (LOGIN),
    FOREIGN KEY (ACTIONID) REFERENCES ACTIONS (ID)
);

insert into PARTICIPANTS values ('Lahvin', 'lahvi', 3102536, null, 0);

drop table ARRIVALS;
create table ARRIVALS
(
    LOGIN varchar(100) NOT NULL,
    ARRTIME varchar(50) NOT NULL,
    PRIMARY KEY (LOGIN),
    FOREIGN KEY (LOGIN) REFERENCES PARTICIPANTS (LOGIN)
);

insert into ARRIVALS values ('Lahvin', '31.11.2011 18:00');

drop table ARRIVALS;
drop table DEPARTURES;
drop table PARTICIPANTS;

create table PARTICIPANTS
(
    LOGIN varchar(100) UNIQUE NOT NULL,
    PASSWORD varchar(100) NOT NULL,
    IDCARTNUM int NOT NULL,
    ADDRESS varchar(200),
    ACTIONID int NOT NULL,
    PRIMARY KEY (IDCARTNUM),
    FOREIGN KEY (ACTIONID) REFERENCES ACTIONS (ID)
);

insert into PARTICIPANTS values ('Lahvin', 'lahvi', 3102536, null, 0);
insert into PARTICIPANTS values ('Petr', 'lahvi', 445262, null, 0);


create table ARRIVALS
(
    LOGIN varchar(100) NOT NULL,
    DEPTIME varchar(50) NOT NULL,
    FOREIGN KEY (LOGIN) REFERENCES PARTICIPANTS (LOGIN)
);

create table DEPARTURES
(
    LOGIN varchar(100) NOT NULL,
    DEPTIME varchar(50) NOT NULL,
    FOREIGN KEY (LOGIN) REFERENCES PARTICIPANTS (LOGIN)
);

insert into arrivals values ('Lahvin', '31.11.2011 18:25');
insert into arrivals values ('Lahvin', '31.11.2011 18:45');
insert into arrivals values ('Petr', '31.11.2011 18:50');
insert into arrivals values ('Lahvin', '31.11.2011 20:05');
insert into arrivals values ('Petr', '31.11.2011 22:15');