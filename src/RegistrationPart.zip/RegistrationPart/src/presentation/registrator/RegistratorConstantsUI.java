/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.registrator;

/**
 *
 * @author Lahvi
 */
public class RegistratorConstantsUI {
    public static final String FIND_DIALOG_BTN = "Vyhledat";
    public static final String BACK_DIALOG_BTN = "Zpět";
    public static final String LOGIN_LBL = "Login účastníka:";
    public static final String PRESENCE_DIALOG_TIT = "Evidence presnece";
    public static final String COMPLETE_DIALOG_TIT = "Dokončení registace účastníka";
    public static final String FIND_RES_LBL = "Nalezen účastník:";
}
