/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.components;

import core.SystemRegException;
import presentation.view.abstract_components.AbstractTablePanel;
import javax.swing.JComboBox;

/**
 *
 * @author Lahvi
 */
public class ActionTablePanel extends AbstractTablePanel<ActionTable, ActionTableModel> {

    public ActionTablePanel() throws SystemRegException {
        super(new ActionTable());
    }

    @Override
    protected void initComboBox() {
        String[] filterOptions = {"Název", "Místo"};
        filterBox = new JComboBox<String>(filterOptions);
        filterBox.setSelectedIndex(1);
    }

    @Override
    protected int getFilterColumnIndex() {
        int index = filterBox.getSelectedIndex();
        filterColumn = index;
        switch (index) {
            case 0:
                return 1;
            case 1:
                return 2;
        }
        return -1;
    }

    @Override
    public void refreshPanel() throws SystemRegException {
        //asi nic
    }
}

