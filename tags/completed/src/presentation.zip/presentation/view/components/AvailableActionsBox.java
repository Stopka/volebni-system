/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.components;

import core.SystemRegException;
import core.data_tier.entities.Action;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Collection;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import presentation.ChangeListener;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.view.MainFrame;

/**
 * Třída implementující {@link javax.swing.JComboBox} bude použita pro výběr akce,
 * které má přihlášený uživatel k dispozici. Bude použita v panelech a dialozích
 * pro správu Účastníků, jako ParticipantTable či ImportDialog.
 * @author Lahvi
 */
public class AvailableActionsBox extends JComboBox<Action> implements ChangeListener {

    /*private static AvailableActionsBox instance;
    
    public static AvailableActionsBox getInstance() throws SystemRegException {
    if (instance == null) {
    instance = new AvailableActionsBox();
    } else {
    instance.initModel();
    }
    return instance;
    }*/
    private final String[] noItems = {"Nemáte přiřazeny žádné akce"};
    private Vector<Action> modelItems;
    private long selectedActionID;

    public AvailableActionsBox() {
        super();

        try {

            addItemListener(new ItemListener() {

                @Override
                public void itemStateChanged(ItemEvent e) {
                    if (e.getStateChange() == ItemEvent.SELECTED) {
                        Action selectedAction = (Action) dataModel.getSelectedItem();
                        if (selectedAction == null) {
                            selectedActionID = -1;
                        } else {
                            selectedActionID = selectedAction.getID();
                        }
                        Globals.getInstance().setSelectedActionID(selectedActionID);
                        Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.ACTIONBOX_SELECTION_CHANGE, this));
                    }

                    /*System.out.println("Byl změněn index. Současný: " + getSelectedIndex() + ""
                    + "\nIndex ID akce nastavené v selectedActionID = " + selectedActionID + "\n"
                    + "Global.getSelectedActionID: " + Globals.getInstance().getSelectedActionID());*/
                }
            });
            initModel();
            Globals.getInstance().addObserverAction(this);
        } catch (SystemRegException ex) {
            removeAllItems();
            Globals.showErr(MainFrame.getMainFrame(), "Nepodařilo se zobrazit dostupné akce.\n" + ex.getMessage());
        }
    }

    private void initModel() throws SystemRegException {
        Collection<Long> userActions = Globals.getInstance().getLogedUser().getActions();
        modelItems = new Vector<Action>(Globals.getInstance().getActionOps().getActions(userActions));
        setModel(new DefaultComboBoxModel<Action>(modelItems));
        if (Globals.getInstance().getSelectedActionID() > -1) {
            selectAction();
        } else {
            if (!modelItems.isEmpty()) {
                setSelectedIndex(0);
                selectedActionID = ((Action)getSelectedItem()).getID();
                Globals.getInstance().setSelectedActionID(selectedActionID);
            }
        }
    }

    @Override
    public void stateChanged(ChangeSource s) {
        try {
            if ((s.getChangeAction() == ChangeSource.ACTION_TABLE_DATA_CHANGE)
                    || s.getChangeAction() == ChangeSource.USER_LIST_DATA_CHANGE) {
                initModel();
            }
            if (s.getChangeAction() == ChangeSource.ACTIONBOX_SELECTION_CHANGE) {
                if (selectedActionID != Globals.getInstance().getSelectedActionID()) {
                    selectAction();
                }
            }
        } catch (SystemRegException ex) {
            Globals.showErr(MainFrame.getMainFrame(), ex);
        }
    }

    private void selectAction() {
        long id = Globals.getInstance().getSelectedActionID();
        for (int i = 0; i < getModel().getSize(); i++) {
            if (((Action) getModel().getElementAt(i)).getID() == id) {
                setSelectedIndex(i);
            }
        }
    }
}
