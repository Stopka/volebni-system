/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.components;

import core.SystemRegException;
import presentation.view.abstract_components.AbstractTable;
import core.data_tier.entities.Action;
import java.util.Collection;
import javax.swing.AbstractAction;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.TableRowSorter;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.controller.actions.CreateActionAction;
import presentation.controller.actions.DeleteActionAction;
import presentation.controller.actions.EditActionAction;
import presentation.controller.dialogs.CreateActionDialog;

/**
 * Třída zděděná od abstraktní třídy {@link AbstractAction} s generickou proměnou
 * typu {@link core.data_tier.entities.Action}. Tabulka, kterou třída reprezentuje,
 * bude zobrazovat všechny akce, ke kterým má přihlášený uživatel právo přistupovat.
 * 
 * @author Lahvi
 */
public class ActionTable extends AbstractTable<Action, ActionTableModel> {

    public ActionTable() throws SystemRegException {
        super(new ActionTableModel());
        sorter = new TableRowSorter<ActionTableModel>(model);
        setRowSorter(sorter);

    }

    @Override
    public Action getSelectedObject() {
        return model.getAction(getSelectedRow());
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int selRow = getSelectedRow();
        
        if (selRow > -1 && selRow < model.getRowCount()) {
            int modelRow = convertRowIndexToModel(selRow);
            if (modelRow > -1) {
                Globals.getInstance().setSelectedAction(getSelectedObject());
            }
        } else {
            Globals.getInstance().setSelectedAction(null);
        }
        Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.ACTION_TABLE_SELECTION_CHANGE, this));
    }

    @Override
    protected void mainAction() {
        new CreateActionDialog(getSelectedObject()).setVisible(true);
    }

    @Override
    protected JPopupMenu createPopupMenu() {
        JMenuItem popitem;
        JPopupMenu popMenu = new JPopupMenu();
        popitem = new JMenuItem(CreateActionAction.getInstance());
        popMenu.add(popitem);
        popitem = new JMenuItem(DeleteActionAction.getInstance());
        popMenu.add(popitem);
        popitem = new JMenuItem(EditActionAction.getInstance());
        popMenu.add(popitem);
        return popMenu;
    }

    @Override
    protected AbstractAction getDeleteAction() {
        return DeleteActionAction.getInstance();
    }

    @Override
    protected void refreshModel() throws SystemRegException {
        model.refreshModel();
    }

    @Override
    public void setModel(Collection<Action> model) {
        this.model.setActions(model);
    }
}
