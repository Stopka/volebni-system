package presentation.view.registrator;

import core.SystemRegException;
import core.data_tier.entities.Participant;
import presentation.view.abstract_components.AbstractParticipantTable;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JPopupMenu;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.controller.dialogs.ParticipantEvidenceDialog;

/**
 * Tabulka zděděná od {@link AbstractParticipantTable} pro registrační část aplikace.
 * Zde se uživateli zobrazí vytvoření účastníci, k dané akci a uživatel jim bude
 * moci dokončit registraci či zaznamenat příchod/odchod.
 * @author Lahvi
 */
public class ParticipantTableRegistrator extends AbstractParticipantTable{

    public ParticipantTableRegistrator() throws SystemRegException {
        super();
    }
    /**
     * Implementuje metodu {@link AbstractParticipantTable#mainAction() }
     * Metoda buď dokončí registraci u vybraného účastníka nebo mu nastaví
     * příchod/odchod (záleží zda je přítomen či ne), podle toho, zda má vybraný 
     * účastník registraci dokončenou či nikoliv.
     */
    @Override
    protected void mainAction() {
        int tabRow = getSelectedRow();
        int r = convertRowIndexToModel(tabRow);
        if (r > -1 && r < model.getRowCount()) {
            Participant p = model.getParticipant(r);
            new ParticipantEvidenceDialog(p, Globals.getInstance().getSelectedActionID()).setVisible(true);
            Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.PAR_TABLE_DATA_CHANGE));
        }
    }

    /**
     * ¨Metoda vrací null, protože v registrátorské části není popup menu k ničemu
     * potřeba.
     * @return 
     */
    @Override
    protected JPopupMenu createPopupMenu() {
        return null;
    }

    /**
     * Vrací akci, která nic nedělá, protože v registrační části uživatel nemůže
     * účastníky mazat.
     * @return 
     */
    @Override
    protected AbstractAction getDeleteAction() {
        return new AbstractAction() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //do nothing
            }
        };
    }
    
}
