/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.abstract_components;

import core.SystemRegException;
import core.data_tier.entities.Participant;
import java.util.Collection;
import javax.swing.AbstractAction;
import javax.swing.JPopupMenu;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.TableRowSorter;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.view.components.ParticipantTableModel;

/**
 * Abstraktní třída která dědí od {@link AbstractTable} a nastavuje generickou 
 * proměnou na typ {@link Participant}. Třída některé metody z rodičovské třídy
 * implementuje a jiné nechává na třídách, které jí budou implementovat. Metody, 
 * které zůstaly abstraktní jsou závislé na tom, jestli tabulka bude použita v 
 * registrační či administrátorské části systému.
 * @author Lahvi
 */
public abstract class AbstractParticipantTable extends AbstractTable<Participant, ParticipantTableModel> {

    /**
     * Proměná, která reprezentuje odkaz na datový model tabulky. 
     */
    public AbstractParticipantTable() throws SystemRegException {
        super(new ParticipantTableModel(Globals.getInstance().getSelectedActionID()));
        sorter = new TableRowSorter<ParticipantTableModel>(model);
        setRowSorter(sorter);

    }

    /**
     * Metoda implementuje metodu z třídy {@link AbstractTable} a vrací vybraného
     * účastníka v tabulce. Pokud není vybrán žádný účastník, vrací null.
     * @return 
     */
    @Override
    public Participant getSelectedObject() {
        return model.getParticipant(getSelectedRow());
    }

    /**
     * Metoda implementuje metodu {@link AbstractTable#valueChanged(javax.swing.event.ListSelectionEvent)}
     * a volá se při změně vybraného indexu v tabulce. Metoda nastaví globální
     * proměnou reprezentující aktuálně vybraného účastníka.
     * @param e 
     */
    @Override
    public void valueChanged(ListSelectionEvent e) {
        int index = getSelectedRow();
        Participant p = null;
        if (index > -1 && index < model.getRowCount()) {
            int converIndex = sorter.convertRowIndexToModel(index);
            if (converIndex > -1 && converIndex < model.getRowCount()) {
                p = model.getParticipant(converIndex);
            }
        }
        Globals.getInstance().setSelectedParticipant(p);
        Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.PAR_TABLE_SELECTION_CHANGE, this));
    }

    @Override
    public void refreshModel() throws SystemRegException {
        model.refresh();
    }

    @Override
    public void setModel(Collection<Participant> model) {
        this.model.setParticipants(model);
    }

    @Override
    protected abstract void mainAction();

    @Override
    protected abstract JPopupMenu createPopupMenu();

    @Override
    protected abstract AbstractAction getDeleteAction();
}
