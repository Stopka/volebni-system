/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.abstract_components;

import presentation.view.MainFrame;
import core.SystemRegException;
import javax.swing.JPanel;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public abstract class AbstractMainFramePanel extends JPanel{
    private MainFrame owner;
    private String role;
    
    public void setRole(String role){
        this.role = role;
    }
    
    public String getRole(){
        return role;
    }
    public void setOwner(MainFrame owner){
        this.owner = owner;
    }
    
    public MainFrame getOwner(){
        return this.owner;
    }
    
   public abstract void refresh() throws SystemRegException;
   
   public abstract void changePanel();
}
