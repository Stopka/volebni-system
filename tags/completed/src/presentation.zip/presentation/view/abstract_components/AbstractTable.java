/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.abstract_components;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.AbstractAction;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.event.ListSelectionEvent;
import core.SystemRegException;
import java.util.Collection;
import javax.swing.ListSelectionModel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableRowSorter;
import presentation.ChangeListener;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.view.MainFrame;

/**
 * Abstraktní tabulka zděděná od {@link javax.swing.JTable}. Třída generická a má
 * proměnou {@code T}, která udává objkety, které bude tabulka obsahovat a proměnou
 * {@code M}, která musí být typu odvozdeného do {@link AbstractTableModel}. Ta 
 * udává typ datového modelu použitý taulkou. Tento model má v sobě tabulka uložený
 * v proměnné {@code model}. Další chráněnou ({@code protected} proměnou v tabulce
 * je {@code sorter}, který je typu {@link TableRowSorter} a slouží k vyhledávání
 * a třídění v řádků v tabulce. Tabulka má nastavené akce na dvoj klik, enter a 
 * delete. Co tyto akce budou dělat určí uživatel v abstraktních metodách
 * {@link AbstractTable#mainAction()} a {@link AbstractTable#getDeleteAction()}.
 * Dále pak má tabulka natavený selection mode na {@code SINGLE_SELECTION}.
 * @author Lahvi
 */
public abstract class AbstractTable<TypeInTable, TableModel extends AbstractTableModel> extends JTable implements ChangeListener {

    protected TableRowSorter<TableModel> sorter;
    protected TableModel model;

    public AbstractTable(TableModel model) {

        this.model = model;
        setModel(model);
        //nastaví akci pro klik pravým tlačítkem a double klik
        addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    mainAction();
                }
                /*if(e.getClickCount() == 1){
                //revalidate();
                
                }*/
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                int r = rowAtPoint(e.getPoint());
                if (r >= 0 && r < getRowCount()) {
                    setRowSelectionInterval(r, r);
                } else {
                    clearSelection();
                }
                repaint();
                int rowindex = getSelectedRow();
                if (rowindex < 0) {
                    return;
                }
                if (e.isPopupTrigger() && e.getComponent() instanceof JTable) {
                    JPopupMenu popup = createPopupMenu();
                    if (popup == null) {
                        return;
                    }
                    popup.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });
        //nastavení pro stisk enteru
        getActionMap().put("EnterAction", new AbstractAction() {

            @Override
            public void actionPerformed(ActionEvent e) {
                mainAction();
            }
        });
        getActionMap().put("DeleteAction", getDeleteAction());
        getInputMap().put(
                KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false),
                "EnterAction");
        getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0, false), "DeleteAction");

        getSelectionModel().addListSelectionListener(this);
        getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Globals.getInstance().addObserverAction(this);
    }

    @Override
    public void stateChanged(ChangeSource s) {
        try {
            if (s.getChangeAction() != ChangeSource.ACTION_TABLE_SELECTION_CHANGE
                    && s.getChangeAction() != ChangeSource.PAR_TABLE_SELECTION_CHANGE) {
                refreshModel();
            }
        } catch (SystemRegException ex) {
            Globals.showErr(MainFrame.getMainFrame(), ex);
        }
    }

    /**
     * Vrátí vybraný objekt. Buď to bude akce nebo účastník.
     * @return 
     */
    public abstract TypeInTable getSelectedObject();

    /**
     * Akce pro změnu vybraného indexu
     * @param e 
     */
    @Override
    public abstract void valueChanged(ListSelectionEvent e);

    /**
     * Metoda vykoná akci, která se spouští na dvojklik nebo enterem
     */
    protected abstract void mainAction();

    /**
     * Metoda vrací JPopMenu po kliknutí pravým tlačítkem na řádek v tabulce
     * Pokud tabulka nemá mít popUpMenu dostupné tak metoda musí vracet null;
     * @return 
     */
    protected abstract JPopupMenu createPopupMenu();

    /**
     * Metoda vrátí akci, která se zavolá na stisk tlačítka delete
     * @return 
     */
    protected abstract AbstractAction getDeleteAction();

    /**
     * Metoda, která aktualizuje datový model tabulky. 
     */
    protected abstract void refreshModel() throws SystemRegException;

    /**
     * Nastaví novou kolekci v modelu
     * @param model 
     */
    public abstract void setModel(Collection<TypeInTable> model);
}
