package presentation.view.admin;

import core.SystemRegException;
import presentation.view.components.ParticipantPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import presentation.controller.actions.CreateParticipantAction;
import presentation.controller.actions.DeleteAction;
import presentation.controller.actions.EditParticipantAction;
import presentation.controller.actions.ImportAction;

/**
 *
 * @author Lahvi
 */
public class ParticipantPanelAdmin extends JPanel {

    private JButton editButton, newButton, deleteButton, importButton;
    private ParticipantPanel<ParticipantTableAdmin> tablePanel;

    public ParticipantPanelAdmin() throws SystemRegException {
        super(new BorderLayout());
        tablePanel = new ParticipantPanel<ParticipantTableAdmin>(new ParticipantTableAdmin());
        editButton = new JButton(EditParticipantAction.getEditParticipant());
        deleteButton = new JButton(DeleteAction.getDeleteAction());
        newButton = new JButton(CreateParticipantAction.getInstance());
        importButton = new JButton(ImportAction.getInstance());
        
        JPanel rightPanel = new JPanel(new GridLayout(4, 1));
        rightPanel.add(newButton);
        rightPanel.add(importButton);
        rightPanel.add(editButton);
        rightPanel.add(deleteButton);
        add(tablePanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.LINE_END);
    }

    /*@Override
    public void refresh() throws SystemRegException {
        tablePanel.refreshPanel();
    }*/

    
}
