/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.admin;

import core.data_tier.entities.Participant;
import core.SystemRegException;
import presentation.view.abstract_components.AbstractParticipantTable;
import java.util.Collection;
import javax.swing.AbstractAction;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import presentation.Globals;
import presentation.controller.actions.CompleteRegAction;
import presentation.controller.actions.DeleteAction;
import presentation.controller.actions.EditParticipantAction;
import presentation.controller.actions.PresenceAction;
import presentation.controller.dialogs.ParticipantDialog;

/**
 *
 * @author Lahvi
 */
public class ParticipantTableAdmin extends AbstractParticipantTable {

    public ParticipantTableAdmin() throws SystemRegException {
        super();
    }

    @Override
    protected void mainAction() {
        int tabRow = getSelectedRow();
        if (tabRow > -1 && tabRow < model.getRowCount()) {
            int r = convertRowIndexToModel(tabRow);
            if (r > -1) {
                try {
                    Participant p = model.getParticipant(r);
                    new ParticipantDialog(p).setVisible(true);
                    model.fireTableDataChanged();
                } catch (SystemRegException ex) {
                    Globals.showErr(this, ex);
                }
            }
        }
    }

    /**
     * Metoda implementuje abstraktní metodu {@link AbstractParticipantTable#createPopupMenu()}.
     * Vrací popup menu, které obsahuje 4 akce a to: Dokončit registraci, Zaznamenat
     * příchod / odchod, smazat účastníka a editovat účastníka.
     * @return 
     */
    @Override
    protected JPopupMenu createPopupMenu() {
        JMenuItem menuItem;
        JPopupMenu popup = new JPopupMenu();
        menuItem = new JMenuItem(CompleteRegAction.getCompleteRegAction());
        popup.add(menuItem);
        menuItem = new JMenuItem(PresenceAction.getPresenceAction());
        popup.add(menuItem);
        menuItem = new JMenuItem(DeleteAction.getDeleteAction());
        popup.add(menuItem);
        menuItem = new JMenuItem(EditParticipantAction.getEditParticipant());
        popup.add(menuItem);
        return popup;
    }

    /**
     * Metoda implementuje abstraktní metodu {@link AbstractParticipantTable#getDeleteAction()}.
     * Vrací akci pro odstranění vybraného účastníka.
     * @return 
     */
    @Override
    protected AbstractAction getDeleteAction() {
        return DeleteAction.getDeleteAction();
    }

    @Override
    public void setModel(Collection<Participant> model) {
        super.setModel(model);
    }
}
