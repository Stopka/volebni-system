package presentation.controller.dialogs;

import core.SystemRegException;
import core.data_tier.entities.Role;
import core.data_tier.entities.User;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import presentation.Globals;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public class ChangeRoleDialog extends AbstractDialog {

    private JComboBox<String> roleBox;
    private User user;
    private JButton actionButton;
    private JButton backButton;

    public ChangeRoleDialog() {
        super();
        setTitle("Změna role");
        this.user = Globals.getInstance().getLogedUser();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        Container conPane = getContentPane();
        conPane.setLayout(new BorderLayout());

        roleBox = new JComboBox<String>();
        roleBox.setEnabled(false);

        switch (user.getRole()) {
            case REGISTRATOR:
                break;
            case ADMIN:
                roleBox.addItem("Registrátor");
                roleBox.addItem("Administrátor");
                roleBox.setEnabled(true);
                break;
            case SUPER_ADMIN:
                roleBox.addItem("Registrátor");
                roleBox.addItem("Administrátor");
                roleBox.addItem("Super Administrátor");
                roleBox.setEnabled(true);
                break;
        }
        selectItem();
        actionButton = new JButton(new AbstractAction("Přepnout") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String chooseRole = (String) roleBox.getSelectedItem();
                    Role actRole = null;
                    if (chooseRole.equals("Registrátor")) {
                        actRole = Role.REGISTRATOR;
                    }
                    if (chooseRole.equals("Administrátor")) {
                        actRole = Role.ADMIN;
                    }
                    if (chooseRole.equals("Super Administrátor")) {
                        actRole = Role.SUPER_ADMIN;
                    }
                    ChangeRoleDialog.this.dispose();
                    ChangeRoleDialog.this.owner.setView(actRole);
                } catch (SystemRegException ex) {
                    Globals.showErr(ChangeRoleDialog.this, ex);
                }
                
            }
        });

        backButton = new JButton(new AbstractAction("Zpět") {

            @Override
            public void actionPerformed(ActionEvent e) {
                ChangeRoleDialog.this.dispose();
            }
        });

        JPanel downPanel = new JPanel(new FlowLayout());
        downPanel.add(actionButton);
        downPanel.add(backButton);
        this.add(downPanel, BorderLayout.PAGE_END);
        this.add(roleBox, BorderLayout.CENTER);
        setSize(new Dimension(300, 103));
        setCenterPos();
    }

    @Override
    protected void init() {
        
    }
    
    private void selectItem(){
        Role actRole = MainFrame.getMainFrame().getActRole();
        switch (actRole){
            case REGISTRATOR:
                roleBox.setSelectedIndex(0);
                break;
            case ADMIN:
                roleBox.setSelectedIndex(1);
                break;
            case SUPER_ADMIN:
                roleBox.setSelectedIndex(2);
                break;
        }
    }
}
