/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.dialogs;

import core.SystemRegException;
import core.data_tier.entities.Participant;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import presentation.Globals;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public class DeleteParticipantDialog extends AbstractDialog{

    /**
     * Dialog vrátí tento příznak pokud uživatel zvolí odstranit účastníka ze 
     * všech akcí.
     */
    public static final int ALL_APROVE = 0;
    /**
     * Dialog vrátí tento příznak pokud uživatel zvolí odstranit účastníka pouze
     * z aktuálně zvolené akce.
     */
    public static final int ONE_ACTION_APROVE = 1;
    /**
     * Dialog vrátí tento příznak pokud uživatel zruší odstraňování.
     */
    public static final int STORNO_APROVE = 2;
    
    
    private Participant deletePar;
    private long actionID;
    private JButton allBtn, oneBtn, stornoBtn;
    private int choosedAction = STORNO_APROVE;
    
    public DeleteParticipantDialog(Participant deletePar, long actionID){
        super();
        this.deletePar = deletePar;
        this.actionID = actionID;
        init();
        setCenterPos();
    }
    @Override
    protected void init() {
        try {
            setTitle("Odstranění účatníka");
            JLabel _deletePar = new JLabel("Účastník: ");
            JLabel _query = new JLabel("Odkud chcete daného účastníka odstanit?", JLabel.CENTER);
            JLabel _action = new JLabel("Aktuálně vybraná akce:");
            JLabel _deleteParString = new JLabel(deletePar.toString());
            JLabel _selectedAction = new JLabel("" + Globals.getInstance().getActionOps().getAction(actionID).getName());
            JPanel topPanel = new JPanel(new BorderLayout(5, 0));
            JPanel lblPanel = new JPanel(new GridLayout(2, 1));
            JPanel valPanel = new JPanel(new GridLayout(2, 1));
            lblPanel.add(_deletePar); lblPanel.add(_action);
            valPanel.add(_deleteParString); valPanel.add(_selectedAction);
            topPanel.add(lblPanel, BorderLayout.LINE_START);
            topPanel.add(valPanel, BorderLayout.CENTER);
            allBtn = new JButton(new AbstractAction("Ze všech akcí") {

                @Override
                public void actionPerformed(ActionEvent e) {
                    choosedAction = ALL_APROVE;
                    dispose();
                }
            });
            
            oneBtn = new JButton(new AbstractAction("Z aktuálně vybrané akce") {

                @Override
                public void actionPerformed(ActionEvent e) {
                    choosedAction = ONE_ACTION_APROVE;
                    dispose();
                }
            });
            
            stornoBtn = new JButton(new AbstractAction("Storno") {

                @Override
                public void actionPerformed(ActionEvent e) {
                    dispose();
                }
            });
            
            
            JPanel btnPanel = new JPanel(new GridLayout(1, 3));
            btnPanel.add(allBtn); btnPanel.add(oneBtn); btnPanel.add(stornoBtn);
            JPanel bottomPanel = new JPanel(new BorderLayout());
            bottomPanel.setBorder(BorderFactory.createTitledBorder("Způsob odstranění:"));
            bottomPanel.add(btnPanel, BorderLayout.CENTER);
            bottomPanel.add(_query, BorderLayout.PAGE_START);
            setLayout(new BorderLayout(0, 5));
            add(topPanel, BorderLayout.CENTER);
            add(bottomPanel, BorderLayout.PAGE_END);
            pack();
            System.out.println("šířka: " + getWidth()); System.out.println("výška: " + getHeight());
        } catch (SystemRegException ex) {
            Globals.showErr(MainFrame.getMainFrame(), "Nepodařilo se zobrazit dialog "
                    + "pro odstranění účatníka z důvodu:\n" + ex.getMessage());
        }
    }
    
    public int showDialog(){
        super.setVisible(true);
        return choosedAction;
    }
    
}
