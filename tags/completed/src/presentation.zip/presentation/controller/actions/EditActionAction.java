/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import core.data_tier.entities.Action;
import java.awt.event.ActionEvent;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.controller.dialogs.CreateActionDialog;

/**
 *
 * @author Lahvi
 */
public class EditActionAction extends AbstractObserverAction{

    private static EditActionAction instance;
    
    public static EditActionAction getInstance(){
        if(instance == null) instance = new EditActionAction();
        return instance;
    }
    
    private EditActionAction(){
        super("Upravit akci");
    }
    @Override
    public boolean isEnabledInState() {
        return !(Globals.getInstance().getSelectedAction() == null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Action selAc = Globals.getInstance().getSelectedAction();
        new CreateActionDialog(selAc).setVisible(true);
        Globals.getInstance().fireStateChange(new ChangeSource(-1, this));
    }
    
}
