/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import presentation.view.LoginScreen;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public class LogoutAction extends AbstractAction {

    private static LogoutAction instance;
    
    public static LogoutAction getInstance(){
        if(instance == null) instance = new LogoutAction();
        return instance;
    }

    private LogoutAction() {
        super("Odhlásit se");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String[] options = {"Ano", "Ne"};
        int res = MainFrame.showOptionDialog("Opravdu se chcete odhlásit?", options, "Odhlášení");
        if (res == JOptionPane.OK_OPTION) {
            MainFrame.getMainFrame().dispose();
            new LoginScreen().setVisible(true);
        }
    }
}
