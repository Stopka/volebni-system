/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import core.data_tier.entities.Role;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import presentation.Globals;
import presentation.controller.dialogs.ChangeRoleDialog;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public class ChangeRoleAction extends AbstractObserverAction{

    private static ChangeRoleAction instance;
    
    public static ChangeRoleAction getInstance(){
        if(instance == null) instance = new ChangeRoleAction();
        return instance;
    }
    private ChangeRoleAction(){
        super("Přepnout Roli");
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        new ChangeRoleDialog().setVisible(true);
    }

    @Override
    public boolean isEnabledInState() {
        return (Globals.getInstance().getLogedUser().getRole() != Role.REGISTRATOR);
    }
    
}
