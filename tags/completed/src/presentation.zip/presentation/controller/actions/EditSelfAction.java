/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.controller.dialogs.EditUserDialog;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public class EditSelfAction extends AbstractAction{

    private static EditSelfAction instance;
    
    public static EditSelfAction getInstance(){
        if(instance == null) instance = new EditSelfAction();
        return instance;
    }
    
    private EditSelfAction(){
        super("Upravit vlastní účet");
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        new EditUserDialog().setVisible(true);
        Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.SELFUSER_DATA_CHANGE, this));
    }
    
}
