/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public class ChangeViewAction extends AbstractAction{
    private static ChangeViewAction instance;
    
    public static ChangeViewAction getInstance(String title){
        if(instance == null) instance = new ChangeViewAction(title);
        return instance;
    }
    
    /*private ChangeViewAction(){
        super()
    }*/
    private ChangeViewAction(String title){
        super(title);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        MainFrame.changeAdminView();
        MainFrame.changeMenu();
        Globals.getInstance().setSelectedAction(null);
        Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.ACTION_TABLE_SELECTION_CHANGE, this));
    }
    
}
