/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import core.SystemRegException;
import core.data_tier.entities.Participant;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.controller.dialogs.DeleteParticipantDialog;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public class DeleteAction extends AbstractObserverAction {

    private static DeleteAction deleteAction;

    public static DeleteAction getDeleteAction() {
        if (deleteAction == null) {
            deleteAction = new DeleteAction();
        }
        return deleteAction;
    }

    private DeleteAction() {
        super("Odstranit účastníka");
    }

    @Override
    public boolean isEnabledInState() {
        if(Globals.getInstance().getSelectedActionID() < 0){
            return false;
        }
        Participant selectedP = Globals.getInstance().getSelectedParticipant();
        if (selectedP != null) {
            return true;
        }
        return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            Participant selectedP = Globals.getInstance().getSelectedParticipant();
            long actionID = Globals.getInstance().getSelectedActionID();
            int option = new DeleteParticipantDialog(selectedP, actionID).showDialog();
            if (option == DeleteParticipantDialog.ALL_APROVE) {
                Globals.getInstance().getParticipantOps().deleteParticipant(selectedP.getId());
                Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.PAR_TABLE_DATA_CHANGE, this));
            } else if(option == DeleteParticipantDialog.ONE_ACTION_APROVE){
                Globals.getInstance().getParticipantOps().removeAction(selectedP.getId(), actionID);
                Globals.getInstance().fireStateChange(new ChangeSource(ChangeSource.PAR_TABLE_DATA_CHANGE, this));
            }
        } catch (SystemRegException ex) {
            Globals.showErr(MainFrame.getMainFrame(), ex);
        }
    }
}
