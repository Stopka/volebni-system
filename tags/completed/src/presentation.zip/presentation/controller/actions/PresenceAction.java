/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import core.data_tier.entities.Participant;
import java.awt.event.ActionEvent;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.controller.dialogs.ParticipantEvidenceDialog;


/**
 *
 * @author Lahvi
 */
public class PresenceAction extends AbstractObserverAction{
    
    private static PresenceAction presenceAction;
    
    public static PresenceAction getPresenceAction(){
        if(presenceAction == null) presenceAction = new PresenceAction();
        return presenceAction;
    }
    private PresenceAction(){
        super("Evidence prezence");
    }
    @Override
    public boolean isEnabledInState() {
        if(Globals.getInstance().getSelectedActionID() < 0)
            return false;   
        
        long actionID = Globals.getInstance().getSelectedActionID();
        Participant selectedP = Globals.getInstance().getSelectedParticipant();
        if(selectedP != null){
            if(selectedP.getActionIDs().contains(actionID) && selectedP.isCompleteReg(actionID)){
                return true;
            }
        }
        return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Participant p = Globals.getInstance().getSelectedParticipant();
        long actionID = Globals.getInstance().getSelectedActionID();
        new ParticipantEvidenceDialog(p, actionID).setVisible(true);
        Globals.getInstance().fireStateChange(new ChangeSource(-1, this));
    }
    
}
