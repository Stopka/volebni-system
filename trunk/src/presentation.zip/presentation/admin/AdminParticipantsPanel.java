/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.admin;

import core.SystemRegException;
import presentation.dialogs.ParticipantDialog;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JPanel;
import presentation.Globals;
import presentation.RefresablePanel;
import presentation.controler.actions.CreateParticipantAction;
import presentation.controler.actions.DeleteAction;
import presentation.controler.actions.EditParticipantAction;
import presentation.controler.actions.ImportAction;

/**
 *
 * @author Lahvi
 */
public class AdminParticipantsPanel extends RefresablePanel {

    private AdminParticipantTable tablePanel;
    private JButton editButton, newButton, deleteButton, importButton;

    public AdminParticipantsPanel() throws SystemRegException {
        super(new BorderLayout());
        tablePanel = new AdminParticipantTable() ;
       

        editButton = new JButton(EditParticipantAction.getEditParticipant());

        deleteButton = new JButton(DeleteAction.getDeleteAction());

        newButton = new JButton(CreateParticipantAction.getInstance());

        importButton = new JButton(ImportAction.getInstance());

        

        JPanel rightPanel = new JPanel(new GridLayout(4, 1));

        rightPanel.add(newButton);
        rightPanel.add(importButton);
        rightPanel.add(editButton);
        rightPanel.add(deleteButton);
        add(tablePanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.LINE_END);
    }

    @Override
    public void refresh() throws SystemRegException {
        tablePanel.refresh();
    }

    
}
