/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controler.actions;

import java.awt.event.ActionEvent;
import presentation.Globals;
import presentation.dialogs.ParticipantDialog;

/**
 *
 * @author Lahvi
 */
public class CreateParticipantAction extends AbstractObserverAction{
    private static CreateParticipantAction instance;
    
    public static CreateParticipantAction getInstance(){
        if(instance == null) instance = new CreateParticipantAction();
        return instance;
    }
    
    public CreateParticipantAction(){
        super("Nový účastník");
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        new ParticipantDialog().setVisible(true);
        Globals.getInstance().refreshData();
    }

    @Override
    public boolean isEnabledInState() {
        return Globals.getInstance().getLogedUser().hasActions();
    }
    
}
