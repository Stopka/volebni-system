/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controler.actions;

import java.awt.event.ActionEvent;
import presentation.Globals;
import presentation.dialogs.ImportDialog;

/**
 *
 * @author Lahvi
 */
public class ImportAction extends AbstractObserverAction{

    private static ImportAction instance;
    
    public static ImportAction getInstance(){
        if(instance == null) instance = new ImportAction();
        return instance;
    }
    
    private ImportAction(){
        super("Importovat");
    }
    @Override
    public boolean isEnabledInState() {
        return Globals.getInstance().getLogedUser().hasActions();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        new ImportDialog().setVisible(true);
        Globals.getInstance().refreshData();
    }
    
}
