/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.dialogs;

import businesstier.utils.ImportUtil;
import core.SystemRegException;
import core.data_tier.entities.Action;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import presentation.Globals;

/**
 *
 * @author Lahvi
 */
public class ImportDialog extends AbstractDialog {

    private JButton loadBtn, browseBtn, additionBtn, okBtn, backBtn;
    private JTextField fileField;
    private JComboBox<String> firstNameBox, lastNameBox, emalBox, cardIDBox;
    private JComboBox<Action> actionsBox;
    private JFileChooser fChooser;
    private String selectedFile;
    private String[] headers;
    private List<Integer> columnsNumber;
    private boolean deuce;

    public ImportDialog() {
        super();
        init();
    }

    //incilaizuje view
    @Override
    protected final void init() {
        setTitle("Importování účastníků");
        setLayout(new BorderLayout(5, 5));
        JPanel loadPanel = new JPanel(new BorderLayout(5, 0)); //panel pro label a textfield
        JPanel topBtnPanel = new JPanel(new GridLayout(1, 2)); //panel pro tlacitka
        JPanel topPanel = new JPanel(new GridLayout(2, 1, 0, 1)); //vrchni panel 
        JPanel actionPanel = new JPanel(new BorderLayout()); //panel pro combobox s akcema
        JLabel _load = new JLabel("Cesta k .csv souboru:");
        fChooser = new JFileChooser();
        fileField = new JTextField();
        fileField.setMinimumSize(new Dimension(65, fileField.getHeight()));
        fileField.setPreferredSize(new Dimension(100, fileField.getHeight()));
        loadBtn = new JButton(new AbstractAction("Načíst") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    loadHeaders();
                } catch (SystemRegException ex) {
                    Globals.showErr(ImportDialog.this, ex);
                }
            }
        });
        browseBtn = new JButton(new AbstractAction("Procházet") {

            @Override
            public void actionPerformed(ActionEvent e) {
                selectFile();
                fileField.setText(selectedFile);
            }
        });

        topBtnPanel.add(browseBtn);
        topBtnPanel.add(loadBtn);
        loadPanel.add(topBtnPanel, BorderLayout.LINE_END);
        loadPanel.add(_load, BorderLayout.LINE_START);
        loadPanel.add(fileField, BorderLayout.CENTER);
        initActionsBox();
        JLabel none = new JLabel();
        //none.setPreferredSize(new Dimension(_load.getWidth(), none.getHeight()));
        actionPanel.add(none, BorderLayout.LINE_START);
        actionPanel.add(actionsBox, BorderLayout.CENTER);
        topPanel.add(loadPanel);
        topPanel.add(actionPanel);
        //Panel s combo boxama
        JPanel boxPanel = new JPanel(new GridLayout(4, 1, 0, 1));
        firstNameBox = new JComboBox<String>();
        firstNameBox.setEnabled(false);
        lastNameBox = new JComboBox<String>();
        lastNameBox.setEnabled(false);
        emalBox = new JComboBox<String>();
        emalBox.setEnabled(false);
        cardIDBox = new JComboBox<String>();
        cardIDBox.setEnabled(false);
        boxPanel.add(firstNameBox);
        boxPanel.add(lastNameBox);
        boxPanel.add(emalBox);
        boxPanel.add(cardIDBox);
        //Panel s labelama
        JPanel lblPanel = new JPanel(new GridLayout(4, 1, 0, 1));
        JLabel _firstN = new JLabel("Křestní jméno:");
        JLabel _lastN = new JLabel("Příjmení:");
        JLabel _email = new JLabel("Email:");
        JLabel _cardID = new JLabel("Číslo OP/Rodné číslo:");
        lblPanel.add(_firstN);
        lblPanel.add(_lastN);
        lblPanel.add(_email);
        lblPanel.add(_cardID);
        //vytvoreni hlaviho view
        JPanel reqPanel = new JPanel(new BorderLayout(5, 0));
        reqPanel.add(lblPanel, BorderLayout.LINE_START);
        reqPanel.add(boxPanel, BorderLayout.CENTER);
        reqPanel.setBorder(BorderFactory.createTitledBorder("Povinné položky"));
        JPanel addPanel = new JPanel(new BorderLayout(5, 0));
        additionBtn = new JButton(new AbstractAction("Přidat volitelné atributy") {

            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });
        addPanel.add(additionBtn, BorderLayout.CENTER);
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(reqPanel, BorderLayout.CENTER);
        mainPanel.add(addPanel, BorderLayout.PAGE_END);

        okBtn = new JButton(new AbstractAction("Importovat") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    getAttIndexes();
                    ImportUtil.importAction(columnsNumber, selectedFile, ((Action)actionsBox.getSelectedItem()).getID());
                    dispose();
                } catch (SystemRegException ex) {
                    Globals.showErr(ImportDialog.this, ex);
                }
            }
        });
        backBtn = new JButton(new AbstractAction("Zpět") {

            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        JPanel btnPanel = new JPanel(new GridLayout(1, 2));
        btnPanel.add(backBtn);
        btnPanel.add(okBtn);
        add(topPanel, BorderLayout.PAGE_START);
        add(mainPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.PAGE_END);
        pack();
        setCenterPos();
    }
    //zobrazi JFileChooser a vybere soubor s .csv souborem

    private void selectFile() {
        int res = fChooser.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            selectedFile = fChooser.getSelectedFile().toString();
        }
    }
    //nacte hlavicky sloupecku a vytvori listy

    private void loadHeaders() throws SystemRegException {
        if (selectedFile == null) {
            selectedFile = fileField.getText();
            if (selectedFile.isEmpty()) {
                throw new SystemRegException("Nejprve musíte vybrat soubor!");
            }
        }
        Collection<String> res = ImportUtil.readHeaders(selectedFile);
        headers = new String[res.size()];
        res.toArray(headers);
        if (headers.length > 0) {
            for (String string : headers) {
                firstNameBox.addItem(string);
                lastNameBox.addItem(string);
                emalBox.addItem(string);
                cardIDBox.addItem(string);
            }
            firstNameBox.setEnabled(true);
            firstNameBox.setSelectedIndex(0);
            lastNameBox.setEnabled(true);
            lastNameBox.setSelectedIndex(0);
            emalBox.setEnabled(true);
            emalBox.setSelectedIndex(0);
            cardIDBox.setEnabled(true);
            cardIDBox.setSelectedIndex(0);
        }
    }
    //nacte dostupne akce prihlaseneho uzivatele

    private void initActionsBox() {
        try {
            Collection<Action> actions = Globals.getInstance().getActionOps().getActions(Globals.getInstance().getLogedUser().getActions());
            actionsBox = new JComboBox<Action>(new Vector<Action>(actions));
        } catch (SystemRegException ex) {
            System.out.println("Co tóó jééé");
        }
    }
    //ziskani vybranych indexu u jednotlivych comboboxu

    private void getAttIndexes() throws SystemRegException {
        int[] indexes = new int[4];
        indexes[0] = firstNameBox.getSelectedIndex();
        indexes[1] = lastNameBox.getSelectedIndex();
        indexes[2] = emalBox.getSelectedIndex();
        indexes[3] = cardIDBox.getSelectedIndex();
        for (int i = 0; i < indexes.length; i++) {
            if (indexes[i] < 0 || indexes[i] > indexes.length) {
                throw new SystemRegException("Musíte ke každému atributu vybrat alepoň jeden sloupec!");
            }
        }
        columnsNumber = new ArrayList<Integer>();
        for (int i = 0; i < indexes.length; i++) {
            if (columnsNumber.contains(indexes[i])) {
                throw new SystemRegException("Jeden sloupec nemůže být přiřazen více parametrům! Vyberte sloupce znovu.");
            }
            columnsNumber.add(indexes[i]);
        }
    }

    public static void main(String[] args) {
        new ImportDialog().setVisible(true);
    }
}
