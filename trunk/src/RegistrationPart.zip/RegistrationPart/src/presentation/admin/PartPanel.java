/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.admin;

import javax.swing.JPanel;
import javax.swing.JTable;

/**
 *
 * @author Lahvi
 */
public class PartPanel extends JPanel{
    private JTable parts;
    
}
