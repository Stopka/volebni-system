/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author Lahvi
 */
public class SystemRegException extends java.lang.Exception {

    public SystemRegException(String msg) {
        super(msg);
    }

    public SystemRegException(Throwable cause) {
        super(cause);
    }
}
