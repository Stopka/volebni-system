
import java.util.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Lahvi
 */
public class Main {

    public static void main(String[] args) {
        /*Calendar doba = Calendar.getInstance();
        doba.set(2011, 1, 2, 14, 29);
        
        Calendar a = Calendar.getInstance();
        a.set(2011, 1, 1, 12, 0);
        Calendar b = Calendar.getInstance();
        b.set(2011, 1, 1, 14, 35);
        Calendar c = Calendar.getInstance();
        c.set(2011, 1, 1, 18, 31);
        Calendar d = Calendar.getInstance();
        d.set(2011, 1, 1, 19, 10);
        Calendar e = Calendar.getInstance();
        e.set(2011, 1, 1, 22, 40);
        Calendar f = Calendar.getInstance();
        f.set(2011, 1, 2, 11, 23);
        Calendar a1 = Calendar.getInstance();
        a1.set(2011, 1, 1, 14, 15);
        Calendar b1 = Calendar.getInstance();
        b1.set(2011, 1, 1, 18, 0);
        Calendar c1 = Calendar.getInstance();
        c1.set(2011, 1, 1, 19, 2);
        Calendar d1 = Calendar.getInstance();
        d1.set(2011, 1, 1, 22, 9);
        Calendar e1 = Calendar.getInstance();
        e1.set(2011, 1, 2, 3, 50);
        
        List<Calendar> prichody = new ArrayList<Calendar>();
        prichody.add(a);
        prichody.add(b);
        prichody.add(c);
        prichody.add(d);
        prichody.add(e);
        prichody.add(f);
        
        List<Calendar> odchody = new ArrayList<Calendar>();
        odchody.add(a1);
        odchody.add(b1);
        odchody.add(c1);
        odchody.add(d1);
        odchody.add(e1);
        
        Calendar[] polePr = new Calendar[prichody.size()];
        prichody.toArray(polePr);
        
        Calendar[] poleOd = new Calendar[odchody.size()];
        odchody.toArray(poleOd);
        
        Calendar[][] intervaly = new Calendar[poleOd.length][2];
        for (int i = 0; i < intervaly.length; i++) {
        intervaly[i][0] = polePr[i];
        intervaly[i][1] = poleOd[i];
        }
        System.out.println("Pole intervalů:");
        for (int i = 0; i < intervaly.length; i++) {
        vypisCalendar(intervaly[i][0], intervaly[i][1]);
        }
        if(prichody.size() > odchody.size()){
        vypisCalendar(polePr[prichody.size()-1]);
        }
        System.out.println("Hledaná doba:");
        vypisCalendar(doba);
        boolean res = false;
        
        if (prichody.size() > odchody.size()) {
        Calendar last = polePr[prichody.size() - 1];
        if (last.compareTo(doba) == -1) {
        res = true;
        }
        }
        for (int i = 0; i < odchody.size(); i++) {
        if(doba.compareTo(intervaly[i][0]) > 0 && doba.compareTo(intervaly[i][1]) < 0){
        res = true;
        break;
        }
        }
        
        if(res){
        System.out.println("Byl");
        } else {
        System.out.println("Nebyl");
        }*/
        
        System.out.println(randomString(8));
    }
    static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static Random rnd = new Random();

    static String randomString(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        }
        return sb.toString();
    }

    public static void vypisCalendar(Calendar c1, Calendar c2) {
        int day1 = c1.get(Calendar.DATE);
        int day2 = c2.get(Calendar.DATE);
        int m1 = c1.get(Calendar.MONTH);
        int m2 = c2.get(Calendar.MONTH);
        int y1 = c1.get(Calendar.YEAR);
        int y2 = c2.get(Calendar.YEAR);

        int h1 = c1.get(Calendar.HOUR_OF_DAY);
        int h2 = c2.get(Calendar.HOUR_OF_DAY);

        int min1 = c1.get(Calendar.MINUTE);
        int min2 = c2.get(Calendar.MINUTE);


        System.out.format("%d.%d.%d %02d:%02d  -  %d.%d.%d %02d:%02d", day1, m1, y1, h1, min1, day2, m2, y2, h2, min2);
        System.out.println("");
    }

    public static void vypisCalendar(Calendar c) {
        int day1 = c.get(Calendar.DATE);
        int m1 = c.get(Calendar.MONTH);
        int y1 = c.get(Calendar.YEAR);
        int h1 = c.get(Calendar.HOUR_OF_DAY);
        int min1 = c.get(Calendar.MINUTE);

        System.out.format("%d.%d.%d %02d:%02d", day1, m1, y1, h1, min1);
        System.out.println("");
    }
}
