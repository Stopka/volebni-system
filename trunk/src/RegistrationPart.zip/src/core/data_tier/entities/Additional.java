/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core.data_tier.entities;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Lahvi
 */
public class Additional {
    private Map<String, String> additionals;
    
    public Additional(Map<String, String> params){
        additionals = new HashMap<String, String>(params);
    }
    
    public Additional(){
        additionals = new HashMap<String, String>();
    }
    
    public String getAdditionalParam(String param){
        return additionals.get(param);
    }
    
    public void removeAddtionalParam(String param){
        additionals.remove(param);
    }
    
    public void addAdditonalParam(String name, String value){
        additionals.put(name, value);
    }
    
    public Map<String, String> getAdditionalParams(){
        return additionals;
    }
    
    public void setAdditionalParams(Map<String, String> params){
        this.additionals = params;
    }
}
