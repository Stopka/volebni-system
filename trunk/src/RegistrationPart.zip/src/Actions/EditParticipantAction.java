/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Actions;

import core.SystemRegException;
import core.data_tier.entities.Action;
import core.data_tier.entities.Participant;
import dialogs.ParticipantDialog;
import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import presentation.Globals;

/**
 *
 * @author Lahvi
 */
public class EditParticipantAction extends AbstractObserverAction{
    
    public EditParticipantAction(){
        super("Upravit účsatníka");
    }

    @Override
    public boolean isEnabledInState() {
        return true;//Globals.getInstance().getSelectedParticipant() != null;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //try {
            /*if(Globals.getInstance().getSelectedParticipant() != null){
                
            }*/
            Collection<Action> all = Globals.getInstance().getActionOps().getActions();
            //Participant p = Globals.getInstance().getParticipantOps().getParticipant(505050);
            new ParticipantDialog(null).setVisible(true);
        //} catch (SystemRegException ex) {
        //    Globals.showErr(null, ex);
        //}
    }
    
}
