/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Actions;

import dialogs.ParticipantDialog;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import core.data_tier.entities.Additional;
import core.data_tier.entities.Participant;

/**
 *
 * @author Lahvi
 */
public class CreateParticipnatAction extends AbstractAction{

    @Override
    public void actionPerformed(ActionEvent e) {
        new ParticipantDialog().setVisible(true);
    }
}
