/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Toolkit;
import javax.swing.JDialog;

/**
 *
 * @author Lahvi
 */
public abstract class AbstractDialog extends JDialog{
    private MainFrame owner;
    
    public AbstractDialog(MainFrame owner){
        super(owner, true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    
    protected void setCenterSize(){
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        int w = getSize().width;
        int h = getSize().height;
        int x = (dim.width - w) / 2;
        int y = (dim.height - h) / 2;
        setLocation(x, y);
    }
}
