/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation;

import Actions.CreateParticipnatAction;
import Actions.EditParticipantAction;
import businesstier.*;
import core.SystemRegException;
import core.data_tier.entities.Action;
import core.data_tier.entities.Participant;
import core.data_tier.entities.User;
import dialogs.ParticipantDialog;
import java.awt.Component;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import javax.naming.NamingException;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeListener;

/**
 *
 * @author Lahvi
 */
public class Globals {

    private static Globals globals;
    private ActionFacade actionOps;
    private ParticipantFacade participantOps;
    private UserFacade userOps;
    private Participant selectedParticipant;
    private Action selectedAction;
    private User selectedUser;
    private User logedUser;
    private long selectedActionID;
    private Set<ChangeListener> registeredActions;

    private Globals() {
        actionOps = new ActionFacade();
        participantOps = new ParticipantFacade();
        userOps = new UserFacade();
        Collection<User> u = new ArrayList<User>(userOps.getUsers());
        for (User user : u) {
            user.addAllAction(actionOps.getActions());
        }
        registeredActions = new HashSet<ChangeListener>();
        
    }
    public void addAction(ChangeListener action){
        registeredActions.add(action);
    }
    
    public void refreshData(){
        if(MainFrame.getMainFrame() != null){
            MainFrame.getMainFrame().refreshData();
        }
        fireStateChange();
    }
    
    public void fireStateChange(){
        for (ChangeListener listener : registeredActions) {
            listener.stateChanged(null);
        }
    }
    
    public Participant getSelectedParticipant(){
        return this.selectedParticipant;
        
    }
    
    public Action getSelectedAction(){
        return this.selectedAction;
    }
    
    public User getSelectedUser(){
        return this.selectedUser;
    }

    public void setSelectedAction(Action selectedAction) {
        this.selectedAction = selectedAction;
    }

    public void setSelectedParticipant(Participant selectedParticipant) {
        this.selectedParticipant = selectedParticipant;
        fireStateChange();
    }

    public void setSelectedUser(User selectedUser) {
        this.selectedUser = selectedUser;
    }
    
    public void setLogedUser(User logedUser){
        this.logedUser = logedUser;
    }
    
    public User getLogedUser(){
        return logedUser;
    }

    public long getSelectedActionID() {
        return selectedActionID;
    }

    public void setSelectedActionID(long selectedActionID) {
        this.selectedActionID = selectedActionID;
        Globals.getInstance().refreshData();
    }
    
    
    
    public static Globals getInstance() {
        if (globals == null) {
            globals = new Globals();
        }
        return globals;
    }

    public ActionFacade getActionOps() {
        return actionOps;
    }

    public ParticipantFacade getParticipantOps() {
        return participantOps;
    }

    public UserFacade getUserOps() {
        return userOps;
    }
    
    

    public static void showErr(Component owner, Exception ex) {
        JOptionPane.showMessageDialog(owner, ex.getMessage(), "Nastala chyba!", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) throws SystemRegException, UnsupportedEncodingException, IOException, NamingException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        
        Globals gl = Globals.getInstance();
        LoginScreen s = new LoginScreen();
        //new ParticipantDialog().setVisible(true);
        //CreateParticipnatAction cpa = new CreateParticipnatAction();
        //cpa.actionPerformed(null);
        //EditParticipantAction epa = new EditParticipantAction();
        //epa.actionPerformed(null);
    }
}
