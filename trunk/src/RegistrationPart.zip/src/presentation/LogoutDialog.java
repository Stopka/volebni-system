/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation;

import javax.swing.JButton;

/**
 *
 * @author Lahvi
 */
public class LogoutDialog extends AbstractDialog{
    private JButton yesBtn, noBtn, cancelBtn;
    public LogoutDialog(MainFrame owner){
        super(owner);
        setTitle("Opravdu se chcete odhlásit?");
        
    }
    
    /*public int showDialog(){
        
    }*/
}
