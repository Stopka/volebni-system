/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.admin;

import java.awt.BorderLayout;
import presentation.RefresablePanel;

/**
 *
 * @author Lahvi
 */
public class ActionPanel extends RefresablePanel{

    public ActionPanel(){
        super(new BorderLayout());
    }

    @Override
    public void refresh() {
        
    }
    
}
