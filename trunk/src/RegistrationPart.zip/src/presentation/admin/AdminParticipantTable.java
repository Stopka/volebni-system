/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.admin;

import core.data_tier.entities.Participant;
import dialogs.ParticipantDialog;
import presentation.ParticipantTablePanel;

/**
 *
 * @author Lahvi
 */
public class AdminParticipantTable extends ParticipantTablePanel {

    @Override
    protected void doubleClickAction() {
        int tabRow = parTable.getSelectedRow();
        int r = parTable.convertRowIndexToModel(tabRow);
        if (r > -1) {

            Participant p = model.getParticipant(r);
            new ParticipantDialog(p).setVisible(true);
            model.fireTableDataChanged();

        }

    }
}
