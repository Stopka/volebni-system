/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.admin;

import presentation.RefresablePanel;
import core.data_tier.entities.User;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Vector;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import presentation.AbstractMainFramePanel;
import presentation.Globals;
import presentation.MainFrame;

/**
 *
 * @author Lahvi
 */
public class AdminPanel extends AbstractMainFramePanel {

    private MainFrame owner;
    private JSplitPane spliter;
    private JPanel viewPanel;
    private RefresablePanel content;
    private boolean actions;

    public AdminPanel() {
        setRole("Admin");
        setLayout(new BorderLayout());
        Vector<User> users = new Vector<User>(Globals.getInstance().getUserOps().getUsers());
        JList persons = new JList(users);
        content = new AdminParticipantsPanel();
        viewPanel = new JPanel(new BorderLayout());
        viewPanel.add(content, BorderLayout.CENTER);
        spliter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, persons, viewPanel);
        add(spliter, BorderLayout.CENTER);
        actions = false;
    }

    @Override
    public void refresh() {
        content.refresh();
    }

    @Override
    public void changePanel() {
        spliter.remove(viewPanel);
        viewPanel = new JPanel(new BorderLayout());
        if (actions) {
            content = new AdminParticipantsPanel();
            viewPanel.add(content, BorderLayout.CENTER);
            actions = false;
        } else {
            content = new ActionPanel();
            viewPanel.add(content, BorderLayout.CENTER);
            actions = true;
        }
        spliter.setRightComponent(viewPanel);
        spliter.revalidate();
        revalidate();
    }
}
