/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.registrator;

import core.data_tier.entities.Participant;
import presentation.MainFrame;
import presentation.ParticipantTablePanel;

/**
 *
 * @author Lahvi
 */
public class RegParticipantTable extends ParticipantTablePanel{

    @Override
    protected void doubleClickAction() {

        int tabRow = parTable.getSelectedRow();
        int r = parTable.convertRowIndexToModel(tabRow);
        if (r > -1) {
            Participant p = model.getParticipant(r);
            if (p.isCompleteReg()) {
                //new ParticipantEvidenceDialog(p, MainFrame.getMainFrame()).setVisible(true);
            } else {
                //new ParticipantEvidenceDialog(p, MainFrame.getMainFrame()).setVisible(true);
            }
            model.fireTableDataChanged();
        }
    }
    
}
