/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dialogs;

import core.data_tier.entities.Action;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.AbstractListModel;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import sun.awt.HorizBagLayout;

/**
 *
 * @author Lahvi
 */
public class ChooseActionDialog extends AbstractDialog implements ListSelectionListener{

    private Collection<Action> allActions;
    private Collection<Action> choosedActions;
    private JList<String> allList, chooseList;
    private ActionListModel allModel, chooseModel;
    private JButton okBtn, backBtn, addBtn, removeBtn;
    
    public ChooseActionDialog(Collection<Action> allActions, Collection<Action> choosedAction){
        this.allActions = new ArrayList<Action>(allActions);
        this.choosedActions = new ArrayList<Action>(choosedAction);
        init();
    }
    
    @Override
    protected void init() {
        setTitle("Vyberte akce do kterých bude účastník přiřazen.");
        setLayout(new BorderLayout());
        allModel = new ActionListModel(allActions);
        chooseModel = new ActionListModel(choosedActions);
        
        allList  = new JList<String>(allModel);
        chooseList = new JList<String>(chooseModel);
        
        allList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        chooseList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        allList.getSelectionModel().addListSelectionListener(this);
        chooseList.getSelectionModel().addListSelectionListener(this);
        addBtn = new JButton(new AbstractAction(">") {

            @Override
            public void actionPerformed(ActionEvent e) {
                addAction();
            }
        });
        addBtn.setEnabled(false);
        
        removeBtn = new JButton(new AbstractAction("<") {

            @Override
            public void actionPerformed(ActionEvent e) {
                removeAction();
            }
        });
        removeBtn.setEnabled(false);
        backBtn = new JButton(new AbstractAction("Zpět") {

            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        okBtn = new JButton(new AbstractAction("OK") {

            @Override
            public void actionPerformed(ActionEvent e) {
                choosedActions = chooseModel.getActions();
                dispose();
            }
        });
        
        JPanel leftPanel = new JPanel(new BorderLayout());
        JPanel rPanel = new JPanel(new BorderLayout());
        JPanel midPanel = new JPanel(); 
        midPanel.setLayout(new BoxLayout(midPanel, BoxLayout.PAGE_AXIS));
        midPanel.add(addBtn); midPanel.add(removeBtn);
        JLabel llab = new JLabel("Dostupné akce");
        JLabel plab = new JLabel("Vybrané akce");
        
        leftPanel.add(llab, BorderLayout.PAGE_START);
        leftPanel.add(allList, BorderLayout.CENTER);
        rPanel.add(plab, BorderLayout.PAGE_START);
        rPanel.add(chooseList, BorderLayout.CENTER);
        
        JPanel btnPanel = new JPanel(new GridLayout(1, 2));
        btnPanel.add(backBtn); btnPanel.add(okBtn);
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.LINE_AXIS));
        mainPanel.add(leftPanel); mainPanel.add(Box.createHorizontalGlue());
        mainPanel.add(midPanel); mainPanel.add(Box.createHorizontalGlue());
        mainPanel.add(rPanel); mainPanel.add(Box.createHorizontalGlue());
        add(mainPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.PAGE_END);
        pack();
        setCenterSize();
    }
    private void addAction(){
        int selectedIndex = allList.getSelectedIndex();
        Action actAct = allModel.getAction(selectedIndex);
        allModel.removeAction(selectedIndex);
        chooseModel.addAction(actAct);
    }
    
    private void removeAction(){
        int selectedIndex = chooseList.getSelectedIndex();
        Action actAct = chooseModel.getAction(selectedIndex);
        chooseModel.removeAction(selectedIndex);
        allModel.addAction(actAct);
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if(chooseList.getSelectedIndex() < 0)
            removeBtn.setEnabled(false);
        else
            removeBtn.setEnabled(true);
        if(allList.getSelectedIndex() < 0)
            addBtn.setEnabled(false);
        else
            addBtn.setEnabled(true);
    }
    
    class ActionListModel extends AbstractListModel<String>{

        private List<Action> actions;
        
        public ActionListModel(Collection<Action> actions){
            this.actions = new ArrayList<Action>(actions);
        }

        
        @Override
        public int getSize() {
            return actions.size();
        }

        @Override
        public String getElementAt(int index) {
            return actions.get(index).getName();
        }
        
        void addAction(Action a){
            actions.add(a);
            fireIntervalAdded(this, 0, actions.size()-1);
        }
        
        Action removeAction(int index){
            Action r = actions.remove(index);
            fireIntervalRemoved(this, index, index);
            return r;
        }
        
        Collection<Action> getActions(){
            return actions;
        }
        
        Action getAction(int index){
            return actions.get(index);
        }
        
    }
}
