/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dialogs;

import businesstier.ActionFacade;
import core.SystemRegException;
import java.awt.event.ActionEvent;
import java.util.Collection;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import core.data_tier.entities.Action;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import core.data_tier.entities.Additional;
import core.data_tier.entities.Participant;
import presentation.Globals;

/**
 *
 * @author Lahvi
 */
public class ParticipantDialog extends AbstractDialog {

    private JButton okBtn, backBtn, additionalBtn;
    private JTextField fName, lName, idNum, email, login, password;
    private Additional a;
    private Participant p;
    private Collection<Action> actions, chooseAct;

    public ParticipantDialog() {
        super();
        p = null;
        a = new Additional();
        this.actions = new ArrayList<Action>(Globals.getInstance().getLogedUser().getActions());
        setTitle("Vytvoření nového účastníka");
        init();
        
    }

    public ParticipantDialog(Participant p){
        this();
        this.chooseAct = new ArrayList<Action>();      
        this.p = p;
        if(p != null)
        a = p.getAddParams();
        setEditValue();
        if(!p.isCompleteReg()){
            login.setEditable(false);
            password.setEditable(false);
        }
    }

    @Override
    protected void init() {
        setLayout(new BorderLayout());
        JPanel reqPanel = new JPanel(new BorderLayout());
        JPanel btnPanel = new JPanel(new GridLayout(2, 1));
        JPanel lblPanel = new JPanel(new GridLayout(7, 1));
        JPanel valuePanel = new JPanel(new GridLayout(7, 1));
        JPanel downBtnPanel = new JPanel(new GridLayout(1, 2));
        
        fName = new JTextField();
        JLabel _fName = new JLabel("Křestní jméno");
        lName = new JTextField();
        JLabel _lName = new JLabel("Příjmení");
        email = new JTextField();
        JLabel _email = new JLabel("Email");
        idNum = new JTextField();
        JLabel _idNum = new JLabel("Číslo OP");
        JLabel _actions = new JLabel("Akce");
        JLabel _login = new JLabel("Login"); JLabel _pswd = new JLabel("Heslo");
        login = new JTextField(); password = new JTextField();
        
        lblPanel.add(_fName);
        valuePanel.add(fName);
        lblPanel.add(_lName);
        valuePanel.add(lName);
        lblPanel.add(_email);
        valuePanel.add(email);
        lblPanel.add(_idNum);
        valuePanel.add(idNum);
        lblPanel.add(_login);
        valuePanel.add(login);
        lblPanel.add(_pswd);
        valuePanel.add(password);
        lblPanel.add(_actions);
        if(p == null){
            login.setEditable(false);
            password.setEditable(false);
        }
        JButton actionBtn = new JButton(new AbstractAction("Přiřadit akce") {

            @Override
            public void actionPerformed(ActionEvent e) {
                new ChooseActionDialog(actions, chooseAct).setVisible(true);
            }
        });
        valuePanel.add(actionBtn);
        reqPanel.add(lblPanel, BorderLayout.LINE_START);
        reqPanel.add(valuePanel, BorderLayout.CENTER);
        reqPanel.setBorder(BorderFactory.createTitledBorder("Povinné údaje"));

        additionalBtn = new JButton(new AbstractAction("Přidat doplňující informace") {

            @Override
            public void actionPerformed(ActionEvent e) {
                new AdditionalDialog(a).setVisible(true);
            }
        });
        backBtn = new JButton("Zpět");
        okBtn = new JButton(new AbstractAction("OK") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    okAction();
                } catch (SystemRegException ex){
                    Globals.showErr(ParticipantDialog.this, ex);
                }
            }
        });
        
        downBtnPanel.add(backBtn);
        downBtnPanel.add(okBtn);

        btnPanel.add(additionalBtn);
        btnPanel.add(downBtnPanel);
        btnPanel.setBorder(BorderFactory.createEmptyBorder(5, 1, 5, 1));
        add(reqPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.PAGE_END);
        pack();
        setCenterSize();
    }


    public void okAction() throws SystemRegException {
        String firstName = fName.getText();
        String lastName = lName.getText();
        String pEmail = email.getText();
        String cardID = idNum.getText();
        
        try{
            int pcardId = Integer.parseInt(cardID);
        Globals.getInstance().getParticipantOps().createParticipant(firstName, lastName, pEmail, pcardId, 0, a);
        } catch (NumberFormatException ex){
            throw new SystemRegException("Číslo OP musí být celé číslo.");
        }
    }
    
    private void setEditValue(){
        fName.setText(p.getFirstName());
        lName.setText(p.getLastName());
        email.setText(p.getEmail());
        idNum.setText(""+p.getCardID());
        setParticipantActions();
    }
    
    //metoda přednastaví akce, které má účastník zvolen
    private void setParticipantActions(){
        Collection<Long> actionIDs = p.getActionIDs();
        
        for (Long long1 : actionIDs) {
            try {
                Action action = Globals.getInstance().getActionOps().getAction(long1);
                if(actions.contains(action)){
                    actions.remove(action);
                    chooseAct.add(action);
                }
                
            } catch (SystemRegException ex) {
                Globals.showErr(this, ex);
            }
        }
        
        
    }
}
