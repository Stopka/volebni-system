/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation;

/**
 *
 * @author Lahvi
 */
public class ChangeSource {
    /**
     * Příznak pokud se na tabulce akcí změnila vybraná akce
     */
    public static final int ACTION_TABLE_SELECTION_CHANGE = 0;
    /**
     * Příznak pokud se na tabulce akcí změnil model nějaké akce
     */
    public static final int ACTION_TABLE_DATA_CHANGE = 1;
    /**
     * Příznak pokud se na tabulce účastníků změnilo vybrání
     */
    public static final int PAR_TABLE_SELECTION_CHANGE = 2;
    /**
     * Příznak pokud se na tabulce účastníků změnil model
     */
    public static final int PAR_TABLE_DATA_CHANGE = 3;
    public static final int ACTIONBOX_SELECTION_CHANGE = 4;
    public static final int USER_LIST_SELECTION_CHANGE = 5;
    public static final int USER_LIST_DATA_CHANGE = 6;
    public static final int SELFUSER_DATA_CHANGE = 7;
    public static final int MAIN_FOR_ALL = 8;
    
    private Object changeSource;
    private int changeAction;
    
    public ChangeSource(int changeAction){
        changeSource = null;
        if(changeAction < 0 || changeAction > MAIN_FOR_ALL){
            changeAction = MAIN_FOR_ALL;
        }
        this.changeAction = changeAction;
    }
    
    public ChangeSource(Object changeSource){
        this(MAIN_FOR_ALL);
        this.changeSource = changeSource;
    }
    
    public ChangeSource(int changeAction, Object changeSource){
        this(changeAction);
        this.changeSource = changeSource;
    }
    
    public int getChangeAction(){
        return changeAction;
    }
    
    public Object getSource(){
        return changeSource;
    }
}
