/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import core.SystemRegException;
import core.data_tier.entities.User;
import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.view.MainFrame;
import sun.awt.GlobalCursorManager;

/**
 *
 * @author Lahvi
 */
public class DeleteUserAction extends AbstractObserverAction{
    private static DeleteUserAction instance;
    
    public static DeleteUserAction getInstance(){
        if(instance == null) instance = new DeleteUserAction();
        return instance;
    }
    
    private DeleteUserAction(){
        super("Odstranit uživatele");
    }
    @Override
    public boolean isEnabledInState() {
        return (Globals.getInstance().getSelectedUser() != null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        User selectedUser = Globals.getInstance().getSelectedUser();
        int res = MainFrame.showOptionDialog("Opravdu chcete uživatele odstranit?");
        if(res == JOptionPane.YES_OPTION){
            try {
                Globals.getInstance().getUserOps().deleteUser(selectedUser.getLogin());
                Globals.getInstance().fireStateChange(new ChangeSource(-1, this));
            } catch (SystemRegException ex) {
               Globals.showErr(MainFrame.getMainFrame(), ex);
            }
        }
            
    }
    
}
