/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.controller.actions;

import java.awt.event.ActionEvent;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.controller.dialogs.ImportDialog;

/**
 *
 * @author Lahvi
 */
public class ImportAction extends AbstractObserverAction{

    private static ImportAction instance;
    
    public static ImportAction getInstance(){
        if(instance == null) instance = new ImportAction();
        return instance;
    }
    
    private ImportAction(){
        super("Importovat");
    }
    @Override
    public boolean isEnabledInState() {
        return Globals.getInstance().getLogedUser().hasActions();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        new ImportDialog().setVisible(true);
        Globals.getInstance().fireStateChange(new ChangeSource(-1, this));
    }
    
}
