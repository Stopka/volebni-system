/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.abstract_components;

import presentation.view.abstract_components.AbstractTable;
import core.SystemRegException;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.AbstractTableModel;
import presentation.ChangeListener;
import presentation.ChangeSource;
import presentation.Globals;
import presentation.view.MainFrame;

/**
 *
 * @author Lahvi
 */
public abstract class AbstractTablePanel<Table extends AbstractTable, M extends AbstractTableModel> extends JPanel implements ChangeListener {

    protected JPanel tablePanel;
    private Table table;
    protected JComboBox<String> filterBox;
    private JTextField filterField;
    private JLabel _filter;
    protected int filterColumn;

    public AbstractTablePanel(Table table) {
        super(new BorderLayout());
        tablePanel = new JPanel(new BorderLayout());
        this.table = table;
        //tablePanel.add(table, BorderLayout.CENTER);
        initComboBox();
        filterBox.setPreferredSize(new Dimension(150, JComboBox.WIDTH));
        filterBox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                filterColumn = getFilterColumnIndex();
            }
        });
        _filter = new JLabel("Vyhledávání: ");
        filterField = new JTextField();
        //okamžitá reakce na jakoukoliv změnu obsahu filtru
        filterField.getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void changedUpdate(DocumentEvent e) {
                newFilter();
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                newFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                newFilter();
            }
        });

        JPanel filterPan = new JPanel(new BorderLayout(5, 0));
        filterPan.add(_filter, BorderLayout.LINE_START);
        filterPan.add(filterField, BorderLayout.CENTER);
        filterPan.add(filterBox, BorderLayout.LINE_END);
        JScrollPane tableScroll = new JScrollPane(table);
        tablePanel.add(tableScroll, BorderLayout.CENTER);
        add(tablePanel, BorderLayout.CENTER);
        add(filterPan, BorderLayout.PAGE_END);
        Globals.getInstance().addObserverAction(this);
    }

    private void newFilter() {
        RowFilter<M, Object> rf = null;
        //If current expression doesn't parse, don't update.
        try {
            rf = RowFilter.regexFilter(filterField.getText(), filterColumn);
        } catch (java.util.regex.PatternSyntaxException e) {
            return;
        }
        table.sorter.setRowFilter(rf);
    }

    /**
     * Metoda, která inicilaizuje comboBox pro vyhledávání v tabulce. V comboBoxu
     * by měly být názvy sloupečků v tabulce, seřazený podle jejich indexů. Právě
     * podle čísel sloupečků (indexů) bude TableRowSorter<M> 
     */
    protected abstract void initComboBox();

    /**
     * Metoda volaná při změně výběru v filterBoxu. Musí vracet index sloupečku
     * v datovém modelu tabulky, který se právě vybral v combo boxu.
     * @return 
     */
    protected abstract int getFilterColumnIndex();

    /**
     * Metoda aktulaizuje model tabulky
     */
    public abstract void refreshPanel() throws SystemRegException;

    public void resetFilter() {
        filterField.setText("");
    }

    public Table getTable() {
        return table;
    }

    @Override
    public void stateChanged(ChangeSource s) {
        try {
            refreshPanel();
        } catch (SystemRegException ex) {
            Globals.showErr(MainFrame.getMainFrame(), ex);
        }
    }
}
