/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.admin;

import presentation.view.components.ActionTablePanel;
import core.SystemRegException;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import presentation.Globals;
import presentation.view.MainFrame;
//import presentation.RefresablePanel;
import presentation.controller.actions.CreateActionAction;
import presentation.controller.actions.DeleteActionAction;
import presentation.controller.actions.EditActionAction;

/**
 *
 * @author Lahvi
 */
public class ActionPanelAdmin extends JPanel {

    private ActionTablePanel tablePanel;
    private JButton createBtn, deleteBtn, editBtn;

    public ActionPanelAdmin() {
        super(new BorderLayout());
        try {
            tablePanel = new ActionTablePanel();
            createBtn = new JButton(CreateActionAction.getInstance());
            editBtn = new JButton(EditActionAction.getInstance());
            deleteBtn = new JButton(DeleteActionAction.getInstance());
            JPanel btnPanel = new JPanel(new GridLayout(3, 1));
            btnPanel.add(createBtn);
            btnPanel.add(editBtn);
            btnPanel.add(deleteBtn);
            add(tablePanel, BorderLayout.CENTER);
            add(btnPanel, BorderLayout.LINE_END);
        } catch (SystemRegException ex) {
            Globals.showErr(MainFrame.getMainFrame(), "Inicializace GUI se "
                    + "nezdařila z důvodu:\n" + ex.getMessage());
            System.exit(1);
        }
    }

    /*@Override
    public void refresh() throws SystemRegException {
        tablePanel.refreshPanel();
    }*/
}
