/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.admin;

import core.SystemRegException;
//import presentation.RefresablePanel;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import presentation.view.abstract_components.AbstractMainFramePanel;
import presentation.Globals;
import presentation.view.components.UserList;

/**
 *
 * @author Lahvi
 */
public class AdminPanel extends AbstractMainFramePanel {
    
    private JSplitPane spliter;
    private JPanel viewPanel;
    private JPanel content;
    private UserList userList;
    private boolean actions;
    
    public AdminPanel() throws SystemRegException {
        setRole("Admin");
        setLayout(new BorderLayout());
        userList = new UserList();
        JScrollPane userListPane = new JScrollPane(userList);
        content = new ParticipantPanelAdmin();
        viewPanel = new JPanel(new BorderLayout());
        viewPanel.add(content, BorderLayout.CENTER);
        spliter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, userListPane, viewPanel);
        add(spliter, BorderLayout.CENTER);
        actions = false;
    }
    
    @Override
    public void refresh() throws SystemRegException {
        /*userList.refresh();
        content.refresh();*/
    }
    
    @Override
    public void changePanel() {
        try {
            spliter.remove(viewPanel);
            viewPanel = new JPanel(new BorderLayout());
            if (actions) {
                content = new ParticipantPanelAdmin();
                viewPanel.add(content, BorderLayout.CENTER);
                actions = false;
            } else {
                content = new ActionPanelAdmin();
                viewPanel.add(content, BorderLayout.CENTER);
                actions = true;
            }
            spliter.setRightComponent(viewPanel);
            spliter.revalidate();
            revalidate();
        } catch (SystemRegException ex) {
            Globals.showErr(this, ex);
        }
    }
}
