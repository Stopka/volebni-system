/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.components;

import presentation.view.components.AvailableActionsBox;
import presentation.view.abstract_components.AbstractTablePanel;
import presentation.view.abstract_components.AbstractParticipantTable;
import businesstier.IParticipantFacade;
import core.SystemRegException;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import presentation.Globals;
import presentation.view.MainFrame;
import presentation.view.admin.ParticipantTableAdmin;
import presentation.view.registrator.ParticipantTableRegistrator;

/**
 * Třída reprezentuje panel, který používá aplikace při zobrazování uživatalů.
 * Je zděděná od třídy {@link AbstractTablePanel}. Jelikož panel používá jak 
 * registrační část aplikace, tak administrátorská, je potřeba specifikovat typ
 * tabulky účatníků, který bude panel obsahovat. Tato tabulka musí být odvozena
 * od {@link AbstractParticipantTable}. To znamená, že zde bude použita
 * buď tabulka {@link ParticipantTableRegistrator}, nebo {@link ParticipantTableAdmin}.
 * Typ této tabulky je reprezentován generickým typem {@code Table}. 
 * Rodičovská třída potřebuje definovat dvě generické proměnné. První je typu {@code 
 * Table}, protože ještě nevíme jakého typu tabulka bude. Druhý generický typ, 
 * který reprezentuje typ datového modelu tabulky, již však známe, takže je použit 
 * typ  {@link ParticipantTableModel}.
 * @author Lahvi
 */
public class ParticipantPanel<Table extends AbstractParticipantTable> extends AbstractTablePanel<Table, ParticipantTableModel>{
    
    
    private AvailableActionsBox actionsBox;
    private JButton allButton, absentBtn, presentBtn, nonRegBtn;
    
    public ParticipantPanel(Table table) throws SystemRegException {
        super(table);
        actionsBox = new AvailableActionsBox();
        add(actionsBox, BorderLayout.PAGE_START);
        allButton = new JButton(new AbstractAction("Zobrazit vše") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    resetFilter();
                    IParticipantFacade pOps = Globals.getInstance().getParticipantOps();
                    getTable().setModel(pOps.getAllParticipants(Globals.getInstance().getSelectedActionID()));
                } catch (SystemRegException ex) {
                    Globals.showErr(MainFrame.getMainFrame(), ex);
                }
            }
        });
        absentBtn = new JButton(new AbstractAction("Zobrazit nepřítomné") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    resetFilter();
                    IParticipantFacade pOps = Globals.getInstance().getParticipantOps();
                    getTable().setModel(pOps.getAbsent(Globals.getInstance().getSelectedActionID()));
                } catch (SystemRegException ex) {
                    Globals.showErr(MainFrame.getMainFrame(), ex);
                }
            }
        });

        presentBtn = new JButton(new AbstractAction("Zobrazit přítomné") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    resetFilter();
                    IParticipantFacade pOps = Globals.getInstance().getParticipantOps();
                    getTable().setModel(pOps.getPresent(Globals.getInstance().getSelectedActionID()));
                } catch (SystemRegException ex) {
                    Globals.showErr(MainFrame.getMainFrame(), ex);
                }
            }
        });

        nonRegBtn = new JButton(new AbstractAction("Zobrazit nezaregistrované") {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    resetFilter();
                    IParticipantFacade pOps = Globals.getInstance().getParticipantOps();
                    getTable().setModel(pOps.getIncompleteRegParticipants(Globals.getInstance().getSelectedActionID()));
                } catch (SystemRegException ex) {
                    Globals.showErr(MainFrame.getMainFrame(), ex);
                }
            }
        });
        JPanel btnPanel = new JPanel(new GridLayout());
        btnPanel.add(allButton);
        btnPanel.add(presentBtn);
        btnPanel.add(absentBtn);
        btnPanel.add(nonRegBtn);
        tablePanel.add(btnPanel, BorderLayout.PAGE_END);
        
        setBottomButtonsEnabled();
    }

    private void setBottomButtonsEnabled(){
        if(Globals.getInstance().getLogedUser().hasActions())
            setBottomButtonsEnabled(true);
        else
            setBottomButtonsEnabled(false);
    }
    private void setBottomButtonsEnabled(boolean enabled){
        allButton.setEnabled(enabled);
        presentBtn.setEnabled(enabled);
        absentBtn.setEnabled(enabled);
        nonRegBtn.setEnabled(enabled);
    }
    
    @Override
    protected void initComboBox() {
        String[] filterOptions = {"Login", "Příjmení", "Email", "Číslo OP"};
        filterBox = new JComboBox<String>(filterOptions);
        filterBox.setSelectedIndex(0);
    }

    @Override
    protected int getFilterColumnIndex() {
        int index = filterBox.getSelectedIndex();
        filterColumn = index;
        switch (index) {
            case 0:
                return  1;
            case 1:
                return 3;
            case 2:
                return 4;
            case 3:
                return 5;
        }
        return -1;
    }
    
    @Override
    public void refreshPanel() throws SystemRegException{
        setBottomButtonsEnabled();
    }

    
    
    
}
