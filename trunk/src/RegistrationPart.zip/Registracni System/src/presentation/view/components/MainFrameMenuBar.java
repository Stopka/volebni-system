/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.components;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import presentation.controller.actions.ChangeRoleAction;
import presentation.controller.actions.ChangeViewAction;
import presentation.controller.actions.CompleteRegAction;
import presentation.controller.actions.CreateActionAction;
import presentation.controller.actions.CreateParticipantAction;
import presentation.controller.actions.CreateUserAction;
import presentation.controller.actions.DeleteAction;
import presentation.controller.actions.DeleteActionAction;
import presentation.controller.actions.DeleteUserAction;
import presentation.controller.actions.EditActionAction;
import presentation.controller.actions.EditParticipantAction;
import presentation.controller.actions.EditSelfAction;
import presentation.controller.actions.EditUserAction;
import presentation.controller.actions.EndAction;
import presentation.controller.actions.ImportAction;
import presentation.controller.actions.LogoutAction;
import presentation.controller.actions.PresenceAction;
import presentation.controller.dialogs.UserDialog;

/**
 *
 * @author Lahvi
 */
public class MainFrameMenuBar extends JMenuBar {
    private JMenuItem[] adminAction;
    private JMenuItem[] adminParticipant;
    private JMenuItem viewItem;
    private JMenu file;
    private JMenu edit;
    private JMenu view;
    private JMenu newMenu;
    private boolean participantView;
    private static MainFrameMenuBar instance;

    public static MainFrameMenuBar getRegistratorMenu() {
        instance = new MainFrameMenuBar();
        return instance;
    }

    public static MainFrameMenuBar getAdminMenu() {
        getRegistratorMenu();
        instance.addAdminMenus();
        return instance;
    }

    /*public static MainFrameMenuBar getSuperAdminMenu() {
        getRegistratorMenu();
        instance.addAdminMenus();
        instance.addSuperAdminMenus();
        return instance;
    }*/

    private MainFrameMenuBar() {
        
        file = new JMenu("Soubor");
        edit = new JMenu("Editace");
        view = new JMenu("Zobrazit");

        file.add(ChangeRoleAction.getInstance());
        file.add(LogoutAction.getInstance());
        file.add(new JSeparator());
        file.add(EndAction.getInstance());

        edit.add(EditSelfAction.getInstance());
        edit.add(new JSeparator());
        edit.add(CompleteRegAction.getCompleteRegAction());
        edit.add(PresenceAction.getPresenceAction());

        add(file);
        add(edit);
    }

    private void addAdminMenus() {
        
        newMenu = new JMenu("Nový");
        newMenu.add(CreateParticipantAction.getInstance());
        newMenu.add(CreateActionAction.getInstance());
        newMenu.add(CreateUserAction.getInstance());

        file.add(new JSeparator());
        file.add(newMenu);
        file.add(ImportAction.getInstance());

        edit.add(new JSeparator());
        edit.add(EditUserAction.getInstance());
        edit.add(DeleteUserAction.getInstance());
        edit.add(new JSeparator());
        viewItem = new JMenuItem(ChangeViewAction.getInstance("Zobrazit akce"));
        view.add(viewItem);
        createParticipantActions();
        add(view);
    }

    /*private void addSuperAdminMenus() {
        newMenu.add(new JSeparator());
        newMenu.add(CreateUserAction.getInstance());
        edit.add(new JSeparator());
        edit.add(EditUserAction.getInstance());
    }*/

    public static void changeAdminView() {
        if(instance.participantView){
            instance.createAdminActions();
        } else {
            instance.createParticipantActions();
        }
    }
    
    private void createAdminActions(){
        JMenuItem editA = new JMenuItem(EditActionAction.getInstance());
        JMenuItem deleteA = new JMenuItem(DeleteActionAction.getInstance());
        
        adminAction = new JMenuItem[2];
        adminAction[0] = editA; adminAction[1] = deleteA;
        
        if(adminParticipant != null){
            for (int i = 0; i < adminAction.length; i++) {
                edit.remove(adminParticipant[i]);
                edit.add(adminAction[i]);
            }
        } else {
            edit.add(adminAction[0]);
            edit.add(adminAction[1]);
        }
        viewItem.setText("Zobrazit účastníky");
        participantView = false;
    }
    
    private void createParticipantActions(){
        JMenuItem editP = new JMenuItem(EditParticipantAction.getEditParticipant());
        JMenuItem deleteP = new JMenuItem(DeleteAction.getDeleteAction());
        
        adminParticipant = new JMenuItem[2];
        adminParticipant[0] = editP; adminParticipant[1] = deleteP;
        
        if(adminAction != null){
            for (int i = 0; i < adminParticipant.length; i++) {
                edit.remove(adminAction[i]);
                edit.add(adminParticipant[i]);
            }
        }else {
            edit.add(adminParticipant[0]);
            edit.add(adminParticipant[1]);
        }
        viewItem.setText("Zobrazit akce");
        participantView = true;
    }
}
