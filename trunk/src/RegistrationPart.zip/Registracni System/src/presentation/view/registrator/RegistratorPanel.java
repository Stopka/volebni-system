/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package presentation.view.registrator;

import core.SystemRegException;
import presentation.view.components.ParticipantPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.*;
import presentation.view.abstract_components.AbstractMainFramePanel;
import presentation.controller.actions.LogoutAction;

/**
 *
 * @author Lahvi
 */
public class RegistratorPanel extends AbstractMainFramePanel{
    private JButton logout;
    private ParticipantPanel<ParticipantTableRegistrator> panel;
    
    public RegistratorPanel() throws SystemRegException{
        setLayout(new BorderLayout());
        setRole("Registrátor");
        logout = new JButton(LogoutAction.getInstance());
        logout.setBackground(Color.red);
       
        logout.setFont(new Font("Courier New",Font.BOLD, 35));
        logout.setPreferredSize(new Dimension(logout.getSize().width, logout.getSize().height + 80));
        
        panel = new ParticipantPanel<ParticipantTableRegistrator>(new ParticipantTableRegistrator());
        
        add(panel);
        add(logout, BorderLayout.PAGE_END);
    }

    @Override
    public void refresh() throws SystemRegException {
        panel.refreshPanel();
    }

    @Override
    public void changePanel() {
        System.out.println("Není podoporováno");
    }
}
